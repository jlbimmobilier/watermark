<?php



require "./watermark.php";

$files = glob('./sources/*.jpg');

$watermark = new Watermark();


foreach($files as $filename)
{
	if(is_file($filename))
	{
		$from = $filename;
		$to = str_replace('sources', 'tagged', $filename);

        $watermark->apply($from, $to, 'watermark.png', 3);
    } 
}

?>