# Ajouter des watermarks à toutes les photos

1. Ouvrir le finder et aller dans `~/Documents/scripts/watermark'
2. Vider le dossier `./sources`
3. Copier les images dans `./sources`. Attention : Uniquement des `.jpg`
4. Ouvrir le `terminal` (`cmd+espace` terminal)
5. `cd ` drag'n'drop de l'icone du dossier watermark dans le terminal.
6. On se retrouve avec cette commande dans le terminal : `cd /Users/jeanlouis/Documents/scripts/watermark/`
7. `enter`
8. taper `pwd` pour s'assurer que nous sommes dans le bon dossier
9. `cd sources`
10. `sips -Z 2300 *.jpg`
11. `cd ..` pour retourner dans le dossier parent (`watermark`)
12. Taper `php index.php` `enter` dans le terminal.
13. `cd tagged`
14. `sips -Z 1200 *.jpg`
15. Récupérer les images avec le watermark et la bonne taille dans `./tagged`

## Automatisation

1. Ouvrir le finder et aller dans `~/Documents/scripts/watermark'
2. Vider le dossier `./sources`
3. Copier les images dans `./sources`. Attention : Uniquement des `.jpg`
4. Ouvrir le `terminal` (`cmd+espace` terminal)
5. `cd ` drag'n'drop de l'icone du dossier watermark dans le terminal.
6. On se retrouve avec cette commande dans le terminal : `cd /Users/jeanlouis/Documents/scripts/watermark/`
7. Taper `pwd` pour s'assurer que l'on est bien dans `watermark`.
8. Taper `sh entrypoint.sh`


## Informations complémentaires:

### Revenir dans le dossier parent

```
cd ..
```

### Connaitre le dossier courant


```
pwd
```

### Redimenssionner des photos en plus grand ou en plus petit
⚠️ : Attention à la taille d'origine des images avant de les redimensinner. Par exemple, une image de 4820X3213 pourra être en 1200px de large mais une image de 150x150 pourra aussi être redimensionnée en 1200px de large.

```
cd aller/dans/le/bon/dossier

sips -Z 1200 *.jpg

```

### Compresser un .jpg avec Google Guetzli
⚠️ : Ne surtout pas lancer cette commande de n'importe où.

```
cd aller/dans/le/bon/dossier

file in ./**/**.jpg; do guetzli "$file" "$file"; printf '.'; done

```
