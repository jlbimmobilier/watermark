#!/bin/bash

#cd /Users/jeanlouis/Documents/scripts/watermark/

pwd

sips -Z 2300 ./sources/*.jpg

php index.php

sips -Z 1000 ./tagged/*.jpg

rm -r ./sources/*
